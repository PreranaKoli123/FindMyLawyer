package com.cdac.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cdac.dto.ReviewDto;
import com.cdac.entity.Review;
import com.cdac.service.ReviewService;

@RestController
@RequestMapping("/api")
public class ReviewController {

  @Autowired
  private ReviewService reviewService;

  @PostMapping("/review")
  public ResponseEntity<String> submitReview(@RequestBody Review reviewRequest) {
    reviewService.submitReview(reviewRequest);
    return ResponseEntity.ok("Review submitted successfully!");
  }
}
