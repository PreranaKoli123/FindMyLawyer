package com.cdac.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

//import com.cdac.entity.Review;
import com.cdac.entity.Review;
import com.cdac.dao.ReviewDao;

@Service
@Transactional
public class ReviewService {

  @Autowired
  private ReviewDao reviewRepository;

  public void submitReview(Review reviewRequest) {
    Review review = new Review();
    review.setAdvocate(reviewRequest.getAdvocate());
    review.setClient(reviewRequest.getClient());
    review.setComment(reviewRequest.getComment());
    review.setRating(reviewRequest.getRating());
    reviewRepository.save(review);
  }
}
