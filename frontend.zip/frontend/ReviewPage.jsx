// src/pages/ReviewPage.js
import React from 'react';
import ReviewForm from '../UserComponent/ReviewForm';

const ReviewPage = () => {
  // Replace these with actual advocateId and clientId
  const advocateId = 1;
  const clientId = 1;

  return (
    <div>
      <ReviewForm advocateId={advocateId} clientId={clientId} />
    </div>
  );
};

export default ReviewPage;
