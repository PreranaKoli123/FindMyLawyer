package com.cdac.dto;

public class ReviewDto {

	
	 private int advocateId;
	  private int clientId;
	  private String comment;
	  private int rating;
	public int getAdvocateId() {
		return advocateId;
	}
	public void setAdvocateId(int advocateId) {
		this.advocateId = advocateId;
	}
	public int getClientId() {
		return clientId;
	}
	public void setClientId(int clientId) {
		this.clientId = clientId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	  
	  
}
