package com.cdac.entity;

import javax.persistence.*;
import lombok.Data;
import java.util.Date;

@Entity
@Data
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private double amount;

    @ManyToOne
    @JoinColumn(name = "appointment_id")
    private Appointment appointment;

    @Temporal(TemporalType.DATE)
    private Date paymentDate;

    private String paymentMethod;

    private String status;

    private String transactionId;
}
